# Viosimos Website

GitHub Pages-ready static website.

## Publish
1. Upload every file and folder in this directory to the root of your GitHub repository.
2. In GitHub, open **Settings → Pages**.
3. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Keep the `assets` folder structure unchanged.

The homepage is `index.html`.
