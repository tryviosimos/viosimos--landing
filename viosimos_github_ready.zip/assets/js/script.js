/* =====================================================================
     JOURNAL POSTS
     To publish a new post, add a new object to the top of this array
     (newest first). No other part of this file needs to change — the
     list on the Journal sub-page renders automatically, and each row
     expands in place when clicked.
     ===================================================================== */
  const posts = [
    {
      id: 'p1',
      date: '2026-07-13',
      tag: { en: 'WELCOME', fr: 'BIENVENUE' },
      title: { en: 'Welcome to the Viosimos Journal', fr: 'Bienvenue sur le Journal Viosimos' },
      body: {
        en: [
          'We spend nearly 90% of our lives indoors, yet many of us know very little about the air we breathe every day. From sleep quality and comfort to home wellness and sustainable living, small changes in our indoor environment can have a meaningful impact on how we feel.',
          'The Viosimos Journal was created to explore these topics through practical advice, research, and insights. As we build Viosimos, we\u2019ll also share our design journey, lessons learned, and the vision behind creating products that combine healthier living with thoughtful design.',
          'Whether you\u2019re here to learn more about indoor air quality or to follow our progress, we\u2019re glad you\u2019ve joined us.'
        ],
        fr: [
          'Nous passons près de 90\u202f% de notre vie à l\u2019intérieur, et pourtant beaucoup d\u2019entre nous en savent très peu sur l\u2019air que nous respirons chaque jour. De la qualité du sommeil et du confort au bien-être à la maison et à un mode de vie durable, de petits changements dans notre environnement intérieur peuvent avoir un impact significatif sur la façon dont nous nous sentons.',
          'Le Journal Viosimos a été créé pour explorer ces sujets à travers des conseils pratiques, des recherches et des points de vue. À mesure que nous construisons Viosimos, nous partagerons également notre parcours de conception, les leçons apprises, et la vision derrière la création de produits qui allient vie plus saine et design réfléchi.',
          'Que vous soyez ici pour en savoir plus sur la qualité de l\u2019air intérieur ou pour suivre notre progression, nous sommes heureux que vous nous ayez rejoints.'
        ]
      }
    }
  ];

  function formatDate(iso, lang){
    const d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString(lang === 'fr' ? 'fr-FR' : 'en-US', { year:'numeric', month:'short', day:'numeric' });
  }

  function renderJournalIndex(lang){
    const list = document.getElementById('journal-index-list');
    if(!list) return;
    const openIds = Array.from(document.querySelectorAll('.index-row.open')).map(r => r.id);
    list.innerHTML = posts.map(p => `
      <div class="index-row" id="row-${p.id}">
        <div class="index-row-top" onclick="toggleRow('${p.id}')">
          <div>
            <span class="index-tag">${p.tag[lang]}</span>
            <span class="index-title">${p.title[lang]}</span>
          </div>
          <span class="index-date">${formatDate(p.date, lang)}</span>
        </div>
        <div class="index-body">
          <div class="index-body-inner">
            ${p.body[lang].map(para => `<p>${para}</p>`).join('')}
          </div>
        </div>
      </div>
    `).join('');
    openIds.forEach(id => document.getElementById(id) && document.getElementById(id).classList.add('open'));
    if(openIds.length === 0 && posts.length){
      document.getElementById('row-' + posts[0].id).classList.add('open');
    }
  }

  function toggleRow(id){
    document.getElementById('row-' + id).classList.toggle('open');
  }

  /* ---------- PAGE-VIEW ROUTING (sub-page inside this same file) ---------- */
  let currentView = 'home';

  function showView(view){
    ['home','journal'].forEach(v=>{
      const el = document.getElementById('view-' + v);
      if(el) el.style.display = (v === view) ? '' : 'none';
    });
    currentView = view;
  }

  function parseHashAndRender(){
    const hash = location.hash;
    const lang = document.documentElement.getAttribute('lang') || 'en';
    if(hash === '#/journal'){
      showView('journal');
      renderJournalIndex(lang);
      window.scrollTo(0, 0);
    } else {
      showView('home');
      if(hash && hash.length > 1 && hash !== '#/'){
        requestAnimationFrame(() => {
          const el = document.getElementById(hash.slice(1));
          if(el) el.scrollIntoView({ behavior:'smooth', block:'start' });
        });
      } else {
        window.scrollTo(0, 0);
      }
    }
  }

  window.addEventListener('hashchange', parseHashAndRender);

  function setLang(lang){
    document.querySelectorAll('[data-en]').forEach(el=>{
      const text = el.getAttribute('data-' + lang);
      if(text !== null) el.textContent = text;
    });
    document.querySelectorAll('[data-en-placeholder]').forEach(el=>{
      const ph = el.getAttribute('data-' + lang + '-placeholder');
      if(ph !== null) el.setAttribute('placeholder', ph);
    });
    document.getElementById('btn-en').classList.toggle('active', lang==='en');
    document.getElementById('btn-fr').classList.toggle('active', lang==='fr');
    document.documentElement.setAttribute('lang', lang);
    if(currentView === 'journal') renderJournalIndex(lang);
  }

  /* ---------- COMMITMENT SCALE ---------- */
  let selectedScore = null;
  function selectScore(v){
    selectedScore = v;
    document.querySelectorAll('.scale-btn').forEach(b=>{
      b.classList.toggle('selected', Number(b.dataset.value) === v);
    });
    document.getElementById('scale-submit-btn').classList.add('active');
  }
  async function submitScore(){
    if(!selectedScore) return;
    const btn = document.getElementById('scale-submit-btn');
    btn.disabled = true;
    try{
      await fetch('https://formspree.io/f/maqrwgpv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({
          commitment_score: selectedScore,
          message: `Viosimos commitment score: ${selectedScore}/10`,
          feature_priority: document.getElementById('feature-priority')?.value || '',
          plant_preference: document.getElementById('plant-preference')?.value || '',
          expected_price_range: document.getElementById('price-range')?.value || '',
          plant_experience: document.getElementById('plant-experience')?.value || '',
          additional_comment: document.getElementById('feedback-comment')?.value || ''
        })
      });
    } catch(err){
      console.error('Commitment score submission failed', err);
    }
    document.getElementById('commitment-scale').style.opacity = '0.45';
    document.getElementById('commitment-scale').style.pointerEvents = 'none';
    btn.style.display = 'none';
    document.getElementById('scale-thanks').classList.add('show');
  }

  /* ---------- DEVELOPMENT MILESTONE ---------- */
  function toggleValidation(){
    const panel = document.getElementById('validation-panel');
    const trigger = document.querySelector('.milestone-toggle');
    if(!panel || !trigger) return;
    const open = panel.classList.toggle('open');
    trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    const lang = document.documentElement.getAttribute('lang') || 'en';
    const label = trigger.querySelector('span');
    if(label) label.textContent = open ? (lang === 'fr' ? 'Voir moins' : 'See less') : (lang === 'fr' ? 'Voir plus' : 'See more');
  }

  /* ---------- MENU DROPDOWN ---------- */
  function toggleMenu(e){
    e.stopPropagation();
    const dd = document.getElementById('menu-dropdown');
    const open = dd.classList.toggle('open');
    dd.querySelector('.menu-trigger').setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  function closeMenu(){
    const dd = document.getElementById('menu-dropdown');
    dd.classList.remove('open');
    dd.querySelector('.menu-trigger').setAttribute('aria-expanded', 'false');
  }
  document.addEventListener('click', (e)=>{
    const dd = document.getElementById('menu-dropdown');
    if(dd && dd.classList.contains('open') && !dd.contains(e.target)) closeMenu();
  });
  document.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape') closeMenu();
  });

  parseHashAndRender();

  // scroll reveal
  const observer = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.classList.add('in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));